from pathlib import Path

import joblib
import pandas as pd
from flask import Flask, jsonify, render_template, request
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split


BASE_DIR = Path(__file__).resolve().parent
DATA_FILE = BASE_DIR / "House_Price_India_in_.csv"
MODEL_FILE = BASE_DIR / "model.pkl"

FEATURES = [
    "number of bedrooms",
    "number of bathrooms",
    "living area",
    "lot area",
    "number of floors",
    "condition of the house",
    "Built Year",
    "Postal Code",
    "Number of schools nearby",
    "Distance from the airport",
]
TARGET = "Price"

FEATURE_RULES = {
    "number of bedrooms": {"label": "Bedrooms", "min": 1, "max": 20},
    "number of bathrooms": {"label": "Bathrooms", "min": 0.5, "max": 10},
    "living area": {"label": "Living area", "min": 200, "max": 15000},
    "lot area": {"label": "Lot area", "min": 400, "max": 1100000},
    "number of floors": {"label": "Floors", "min": 1, "max": 4},
    "condition of the house": {"label": "House condition", "min": 1, "max": 5},
    "Built Year": {"label": "Built year", "min": 1900, "max": 2026},
    "Postal Code": {"label": "Postal code", "min": 100000, "max": 999999},
    "Number of schools nearby": {"label": "Schools nearby", "min": 0, "max": 10},
    "Distance from the airport": {"label": "Airport distance", "min": 1, "max": 200},
}

app = Flask(__name__)


def load_data():
    if not DATA_FILE.exists():
        raise FileNotFoundError(f"Dataset not found: {DATA_FILE.name}")

    data = pd.read_csv(DATA_FILE)
    missing = [column for column in FEATURES + [TARGET] if column not in data.columns]
    if missing:
        raise ValueError(f"Dataset is missing columns: {', '.join(missing)}")

    return data.dropna(subset=FEATURES + [TARGET])


def train_or_load_model():
    data = load_data()
    x = data[FEATURES]
    y = data[TARGET]

    if MODEL_FILE.exists():
        model = joblib.load(MODEL_FILE)
    else:
        model = RandomForestRegressor(
            n_estimators=180,
            random_state=42,
            min_samples_leaf=2,
            n_jobs=-1,
        )
        model.fit(x, y)
        joblib.dump(model, MODEL_FILE)

    x_train, x_test, y_train, y_test = train_test_split(
        x, y, test_size=0.2, random_state=42
    )
    score_model = RandomForestRegressor(
        n_estimators=180,
        random_state=42,
        min_samples_leaf=2,
        n_jobs=-1,
    )
    score_model.fit(x_train, y_train)
    r2 = r2_score(y_test, score_model.predict(x_test))

    importances = [
        {"feature": feature, "importance": round(float(value), 4)}
        for feature, value in sorted(
            zip(FEATURES, model.feature_importances_),
            key=lambda item: item[1],
            reverse=True,
        )
    ]

    stats = {
        "total_records": int(len(data)),
        "avg_price": int(data[TARGET].mean()),
        "min_price": int(data[TARGET].min()),
        "max_price": int(data[TARGET].max()),
    }
    metrics = {"r2": round(r2 * 100, 1)}

    return model, stats, metrics, importances


model, dataset_stats, model_metrics, feature_importance = train_or_load_model()


@app.route("/")
def index():
    return render_template(
        "index.html",
        stats=dataset_stats,
        metrics=model_metrics,
        feat_imp=feature_importance,
    )


@app.route("/predict", methods=["POST"])
def predict():
    payload = request.get_json(silent=True) or {}

    values = {}
    errors = []
    for feature in FEATURES:
        rule = FEATURE_RULES[feature]
        try:
            value = float(payload[feature])
        except (KeyError, TypeError, ValueError):
            errors.append(f"{rule['label']} is required and must be a number.")
            continue

        if value < rule["min"] or value > rule["max"]:
            errors.append(
                f"{rule['label']} must be between {rule['min']} and {rule['max']}."
            )
            continue

        values[feature] = value

    if errors:
        return jsonify({"success": False, "errors": errors}), 400

    row = pd.DataFrame([values], columns=FEATURES)
    price = max(0, float(model.predict(row)[0]))
    low = price * 0.85
    high = price * 1.15

    if price < 2_500_000:
        tier = "Budget"
    elif price < 7_500_000:
        tier = "Mid-range"
    else:
        tier = "Luxury"

    return jsonify(
        {
            "success": True,
            "price": round(price),
            "range_low": round(low),
            "range_high": round(high),
            "tier": tier,
            "inputs": values,
        }
    )


@app.route("/health")
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    app.run(debug=True)
